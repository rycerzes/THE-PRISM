import { Client } from 'pg';

export interface DBClient {

};

export class DBClient extends Client {
    constructor() {

        super({
            connectionString: process.env.DATABASE_URL
        })

    };
};